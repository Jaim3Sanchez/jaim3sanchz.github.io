<HTML>
<HEAD>
<TITLE>Primera Pagina</TITLE>
</HEAD>
<BODY background="imagen.jpg" text=white >
<a href=https://www.google.com>  click here </a>
<a href=
<B>Hola que tal</B>
</BR>
<U>Hola que tal</U>
<time>10/1/2019</time>
<button>PULSA</button>
<details>hola</details>
</BODY>
<marquee direction="up">Mira aqui</marquee>
</HTML>